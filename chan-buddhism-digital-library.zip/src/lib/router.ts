import { useEffect, useState } from "react";

export interface Route {
  room: string;
  id?: string;
}

function parse(): Route {
  const raw = window.location.hash.replace(/^#\/?/, "");
  const parts = raw.split("/").filter(Boolean);
  return { room: parts[0] || "home", id: parts[1] ? decodeURIComponent(parts[1]) : undefined };
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(parse);
  useEffect(() => {
    const onHash = () => {
      setRoute(parse());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  return route;
}

export function go(room: string, id?: string) {
  window.location.hash = `/${room}${id ? "/" + encodeURIComponent(id) : ""}`;
}

export const href = (room: string, id?: string) => `#/${room}${id ? "/" + encodeURIComponent(id) : ""}`;
