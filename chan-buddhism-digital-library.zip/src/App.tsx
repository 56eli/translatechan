import Layout from "./components/Layout";
import { PrefsProvider } from "./components/ui";
import { useRoute } from "./lib/router";
import Home from "./rooms/Home";
import Read from "./rooms/Read";
import Compare from "./rooms/Compare";
import Lineage from "./rooms/Lineage";
import Cases from "./rooms/Cases";
import Terms from "./rooms/Terms";

export default function App() {
  const { room, id } = useRoute();

  let view;
  switch (room) {
    case "read":
      view = <Read id={id} />;
      break;
    case "compare":
      view = <Compare />;
      break;
    case "lineage":
      view = <Lineage id={id} />;
      break;
    case "cases":
      view = <Cases id={id} />;
      break;
    case "terms":
      view = <Terms id={id} />;
      break;
    default:
      view = <Home />;
  }

  return (
    <PrefsProvider>
      <Layout room={room}>{view}</Layout>
    </PrefsProvider>
  );
}
