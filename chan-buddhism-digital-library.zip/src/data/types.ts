export type Status = "verified" | "review" | "unsourced";

export interface Passage {
  id: string;
  zh: string;
  pinyin: string;
  en: string;
  note?: string;
  status: Status;
  witness?: string; // which edition this reading follows
}

export interface Text {
  id: string;
  titleEn: string;
  titleZh: string;
  pinyin: string;
  genre: "Verse" | "Sermon" | "Record" | "Koan collection" | "Manual" | "History" | "Sutra";
  dateLabel: string;
  century: number; // for sorting
  attributed: string; // teacher id or plain name
  place: string;
  oneLine: string; // plain English, 1 sentence
  origin: string; // where did this come from
  background: string; // why it matters
  firstTime: string; // "if you read one thing"
  related: string[]; // text ids
  teachers: string[]; // teacher ids
  terms: string[];
  slots: number;
  verified: number;
  flagged: number;
  passages: Passage[];
}

export interface Teacher {
  id: string;
  nameZh: string;
  pinyin: string;
  dates: string;
  century: number;
  house: string; // lineage house
  place: string;
  teacher?: string; // teacher id
  students: string[];
  oneLine: string;
  story: string;
  why: string;
  texts: string[];
  cases: string[];
  saying?: { zh: string; pinyin: string; en: string; status: Status };
}

export interface KoanCase {
  id: string;
  number: number;
  collection: string;
  collectionZh: string;
  titleZh: string;
  titlePinyin: string;
  titleEn: string;
  zh: string;
  pinyin: string;
  en: string;
  status: Status;
  setting: string; // plain background
  pointer: string; // what to notice
  misread: string; // common misreading
  teachers: string[];
  terms: string[];
}

export interface Term {
  id: string;
  zh: string;
  pinyin: string;
  en: string;
  plain: string;
  deeper: string;
  literal: string;
  related: string[];
  appearsIn: string[]; // text ids
}

export interface Witness {
  id: string;
  nameEn: string;
  nameZh: string;
  dateLabel: string;
  kind: string;
  blurb: string;
  reliability: string;
}

export interface VariantLine {
  id: string;
  textId: string;
  label: string;
  en: string;
  readings: { witnessId: string; zh: string; note: string; status: Status }[];
  comment: string;
}
