import { useMemo, useState } from "react";
import { texts, textById } from "../data/texts";
import { teacherById } from "../data/teachers";
import { termById } from "../data/terms";
import { href } from "../lib/router";
import { Disclosure, Field, LinkRow, Passage, RoomTitle, StatusDot } from "../components/ui";

const genres = ["All", "Verse", "Sermon", "Record", "Koan collection", "Manual", "History", "Sutra"] as const;

function Index() {
  const [genre, setGenre] = useState<string>("All");
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    return texts
      .filter((t) => (genre === "All" ? true : t.genre === genre))
      .filter((t) =>
        q.trim()
          ? (t.titleEn + t.titleZh + t.pinyin + t.oneLine).toLowerCase().includes(q.toLowerCase())
          : true,
      )
      .sort((a, b) => a.century - b.century);
  }, [genre, q]);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <RoomTitle
        eyebrow="Room one · Read"
        title="The works"
        lede="Thirty-five source texts, arranged oldest first. Each one opens with a single sentence telling you what it is; everything else — origin, background, relations, the Chinese itself — waits behind an expander until you want it."
      />

      <div className="mb-10 flex flex-wrap items-center gap-2">
        {genres.map((g) => (
          <button
            key={g}
            onClick={() => setGenre(g)}
            className={`rounded-full px-3.5 py-1.5 text-[0.85rem] transition ${
              genre === g
                ? "bg-stone-800 text-[#F8F5EF]"
                : "border border-stone-300 text-stone-600 hover:border-stone-500"
            }`}
          >
            {g}
          </button>
        ))}
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search titles…"
          className="ml-auto w-48 rounded-full border border-stone-300 bg-white/60 px-4 py-1.5 text-[0.85rem] text-stone-700 outline-none placeholder:text-stone-400 focus:border-[#9A3B1E]/50"
        />
      </div>

      <ol className="border-t border-stone-200">
        {list.map((t) => (
          <li key={t.id}>
            <a
              href={href("read", t.id)}
              className="group grid gap-x-6 gap-y-1.5 border-b border-stone-200 py-6 transition hover:bg-white/60 sm:grid-cols-[7rem_1fr_auto]"
            >
              <span className="text-[0.8rem] uppercase tracking-[0.1em] text-stone-400">{t.dateLabel.split(";")[0]}</span>
              <span>
                <span className="font-serif text-[1.18rem] text-stone-800 group-hover:text-[#9A3B1E]">
                  {t.titleEn}
                </span>
                <span
                  lang="zh"
                  className="ml-3 text-[0.98rem] text-stone-400"
                  style={{ fontFamily: "'Noto Serif SC', serif" }}
                >
                  {t.titleZh}
                </span>
                <span className="mt-1.5 block max-w-[40rem] text-[0.95rem] leading-[1.7] text-stone-600">
                  {t.oneLine}
                </span>
              </span>
              <span className="self-start text-[0.75rem] uppercase tracking-[0.12em] text-stone-400 sm:text-right">
                {t.genre}
              </span>
            </a>
          </li>
        ))}
      </ol>
      {!list.length && <p className="py-10 text-stone-500">Nothing matches that.</p>}
    </div>
  );
}

function Detail({ id }: { id: string }) {
  const t = textById(id);
  if (!t) return <Index />;
  const author = teacherById(t.attributed);
  const idx = texts.findIndex((x) => x.id === t.id);
  const prev = texts[(idx - 1 + texts.length) % texts.length];
  const next = texts[(idx + 1) % texts.length];

  return (
    <article className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
      <a href={href("read")} className="text-[0.85rem] text-stone-500 hover:text-[#9A3B1E]">
        ← all works
      </a>

      <div className="mt-8 grid gap-14 lg:grid-cols-[minmax(0,44rem)_1fr]">
        {/* reading column */}
        <div>
          <header className="mb-10">
            <p className="mb-3 text-[0.7rem] uppercase tracking-[0.2em] text-[#9A3B1E]">
              {t.genre} · {t.dateLabel}
            </p>
            <h1 className="font-serif text-[2.2rem] leading-tight text-stone-800">{t.titleEn}</h1>
            <p className="mt-3 flex flex-wrap items-baseline gap-x-4 text-stone-500">
              <span
                lang="zh"
                className="text-[1.5rem] text-stone-600"
                style={{ fontFamily: "'Noto Serif SC', serif" }}
              >
                {t.titleZh}
              </span>
              <span className="text-[0.95rem] italic">{t.pinyin}</span>
            </p>
            <p className="mt-6 text-[1.1rem] leading-[1.85] text-stone-700">{t.oneLine}</p>
          </header>

          <section className="mb-12 rounded-lg border border-stone-200 bg-white/50 p-6">
            <p className="text-[0.68rem] uppercase tracking-[0.16em] text-stone-400">If you read one thing</p>
            <p className="mt-2 text-[1rem] leading-[1.8] text-stone-700">{t.firstTime}</p>
          </section>

          <section className="mb-12">
            <h2 className="mb-6 font-serif text-[1.35rem] text-stone-800">Passages</h2>
            <div className="space-y-10">
              {t.passages.map((p) => (
                <Passage key={p.id} {...p} big />
              ))}
            </div>
            <p className="mt-8 text-[0.82rem] leading-relaxed text-stone-500">
              {t.verified} of this work's {t.slots} text slots are published as verified; {t.flagged} are flagged
              for source review and are not shown until a named edition confirms them.
            </p>
          </section>
        </div>

        {/* dossier */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <p className="mb-1 text-[0.68rem] uppercase tracking-[0.18em] text-stone-400">Dossier</p>
          <p className="mb-5 text-[0.85rem] leading-relaxed text-stone-500">
            Plain answers to the four questions people actually ask.
          </p>

          <div className="rounded-lg border border-stone-200 bg-white/50 px-5">
            <Disclosure label="Where did this come from?" hint="origin">
              <Field label="Attributed to">
                {author ? (
                  <a className="text-[#9A3B1E] underline underline-offset-4" href={href("lineage", author.id)}>
                    {author.pinyin} {author.nameZh}
                  </a>
                ) : (
                  t.attributed
                )}
              </Field>
              <Field label="Time and place">
                {t.dateLabel} · {t.place}
              </Field>
              <p>{t.origin}</p>
            </Disclosure>

            <Disclosure label="What is the background?" hint="context">
              <p>{t.background}</p>
            </Disclosure>

            <Disclosure label="Who and what is related?" hint="links">
              <Field label="Related works">
                <LinkRow
                  items={t.related
                    .map((r) => textById(r))
                    .filter(Boolean)
                    .map((r) => ({ label: r!.titleEn, room: "read", id: r!.id }))}
                />
              </Field>
              <Field label="People">
                <LinkRow
                  items={t.teachers
                    .map((r) => teacherById(r))
                    .filter(Boolean)
                    .map((r) => ({ label: r!.pinyin, room: "lineage", id: r!.id }))}
                />
              </Field>
              <Field label="Vocabulary used here">
                <LinkRow
                  items={t.terms
                    .map((r) => termById(r))
                    .filter(Boolean)
                    .map((r) => ({ label: r!.en, room: "terms", id: r!.id }))}
                />
              </Field>
            </Disclosure>

            <Disclosure label="How reliable is the text?" hint="provenance">
              <div className="mb-4 flex flex-wrap gap-4 text-[0.85rem]">
                <span className="flex items-center gap-2">
                  <StatusDot status="verified" /> {t.verified} verified
                </span>
                <span className="flex items-center gap-2">
                  <StatusDot status="review" /> {t.flagged} flagged
                </span>
                <span className="text-stone-400">{t.slots} slots total</span>
              </div>
              <p>
                Nothing in the Chinese above has been normalised, punctuated silently or corrected. Where
                editions disagree, both readings are carried in the{" "}
                <a className="text-[#9A3B1E] underline underline-offset-4" href={href("compare")}>
                  Compare
                </a>{" "}
                room rather than resolved here.
              </p>
            </Disclosure>
          </div>

          <div className="mt-8 flex justify-between gap-4 text-[0.85rem]">
            <a href={href("read", prev.id)} className="max-w-[45%] text-stone-500 hover:text-[#9A3B1E]">
              ← {prev.titleEn}
            </a>
            <a href={href("read", next.id)} className="max-w-[45%] text-right text-stone-500 hover:text-[#9A3B1E]">
              {next.titleEn} →
            </a>
          </div>
        </aside>
      </div>
    </article>
  );
}

export default function Read({ id }: { id?: string }) {
  return id ? <Detail id={id} /> : <Index />;
}
