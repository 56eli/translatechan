import { useState } from "react";
import { teachers, teacherById } from "../data/teachers";
import { textById } from "../data/texts";
import { cases } from "../data/cases";
import { href } from "../lib/router";
import { Disclosure, Field, LinkRow, Passage, RoomTitle } from "../components/ui";

const eras = [
  { c: [5, 6], label: "5th–6th century", note: "Legendary beginnings: a few names, almost no documents." },
  { c: [7], label: "7th century", note: "Chan becomes a settled, farming, teaching community." },
  { c: [8], label: "8th century", note: "The split into northern and southern, and the rise of Mazu's hall." },
  { c: [9], label: "9th century", note: "The classical age: Linji, Zhaozhou, Dongshan, and persecution in 845." },
  { c: [10, 11], label: "10th–11th century", note: "The five houses settle; Chan is written down and systematised." },
  { c: [12, 13], label: "12th–13th century", note: "Koan collections, silent illumination, and a public argument." },
  { c: [16], label: "16th century onward", note: "Ming revival: gathering, reforming, worrying about decline." },
];

function Index() {
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <RoomTitle
        eyebrow="Room three · Lineage"
        title="Who taught whom"
        lede="Chan describes itself as a chain of people rather than a body of doctrine. That chain is partly historical and partly a claim made later, in public, for good reasons. Here it is laid out by century, with each person in one sentence."
      />

      <div className="mb-14 rounded-lg border border-stone-200 bg-white/50 p-6 text-[0.95rem] leading-[1.8] text-stone-600">
        <p className="mb-2 font-serif text-[1.05rem] text-stone-800">Before you read a family tree</p>
        The neat diagrams were mostly drawn in the eleventh century, when Chan needed to prove it descended
        from the Buddha in an unbroken line. Some links are solid, some are retrospective tidying. This site
        marks the difference in each person's dossier rather than hiding it.
      </div>

      <div className="space-y-16">
        {eras.map((era) => {
          const group = teachers.filter((t) => era.c.includes(t.century));
          if (!group.length) return null;
          return (
            <section key={era.label}>
              <div className="mb-6 border-b border-stone-200 pb-3">
                <h2 className="font-serif text-[1.35rem] text-stone-800">{era.label}</h2>
                <p className="mt-1 text-[0.92rem] text-stone-500">{era.note}</p>
              </div>
              <div className="grid gap-px overflow-hidden rounded-lg border border-stone-200 bg-stone-200 sm:grid-cols-2 lg:grid-cols-3">
                {group.map((t) => {
                  const teacher = t.teacher ? teacherById(t.teacher) : undefined;
                  const isOpen = open === t.id;
                  return (
                    <div key={t.id} className="bg-[#F8F5EF] p-6">
                      <div className="flex items-baseline justify-between gap-3">
                        <a href={href("lineage", t.id)} className="font-serif text-[1.1rem] text-stone-800 hover:text-[#9A3B1E]">
                          {t.pinyin}
                        </a>
                        <span
                          lang="zh"
                          className="text-[0.95rem] text-stone-400"
                          style={{ fontFamily: "'Noto Serif SC', serif" }}
                        >
                          {t.nameZh}
                        </span>
                      </div>
                      <p className="mt-1 text-[0.78rem] uppercase tracking-[0.1em] text-stone-400">{t.dates}</p>
                      <p className="mt-3 text-[0.93rem] leading-[1.7] text-stone-600">{t.oneLine}</p>
                      <button
                        onClick={() => setOpen(isOpen ? null : t.id)}
                        className="mt-4 text-[0.8rem] text-stone-400 underline-offset-4 hover:text-[#9A3B1E] hover:underline"
                      >
                        {isOpen ? "less" : "lineage & links"}
                      </button>
                      {isOpen && (
                        <div className="mt-3 space-y-1.5 text-[0.85rem] leading-relaxed text-stone-500">
                          <p>
                            <span className="text-stone-400">House: </span>
                            {t.house}
                          </p>
                          <p>
                            <span className="text-stone-400">Taught by: </span>
                            {teacher ? (
                              <a className="text-[#9A3B1E] hover:underline" href={href("lineage", teacher.id)}>
                                {teacher.pinyin}
                              </a>
                            ) : (
                              "not recorded in this corpus"
                            )}
                          </p>
                          <p>
                            <span className="text-stone-400">Students here: </span>
                            {t.students.length
                              ? t.students.map((s, i) => (
                                  <span key={s}>
                                    {i > 0 && ", "}
                                    <a className="text-[#9A3B1E] hover:underline" href={href("lineage", s)}>
                                      {teacherById(s)?.pinyin ?? s}
                                    </a>
                                  </span>
                                ))
                              : "—"}
                          </p>
                          <a href={href("lineage", t.id)} className="inline-block pt-1 text-[#9A3B1E] hover:underline">
                            full dossier →
                          </a>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function Detail({ id }: { id: string }) {
  const t = teacherById(id);
  if (!t) return <Index />;
  const teacher = t.teacher ? teacherById(t.teacher) : undefined;
  const theirCases = cases.filter((c) => c.teachers.includes(t.id));

  return (
    <article className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
      <a href={href("lineage")} className="text-[0.85rem] text-stone-500 hover:text-[#9A3B1E]">
        ← all teachers
      </a>
      <div className="mt-8 grid gap-14 lg:grid-cols-[minmax(0,40rem)_1fr]">
        <div>
          <p className="mb-3 text-[0.7rem] uppercase tracking-[0.2em] text-[#9A3B1E]">{t.house}</p>
          <h1 className="font-serif text-[2.2rem] leading-tight text-stone-800">{t.pinyin}</h1>
          <p className="mt-3 flex flex-wrap items-baseline gap-x-4 text-stone-500">
            <span lang="zh" className="text-[1.5rem] text-stone-600" style={{ fontFamily: "'Noto Serif SC', serif" }}>
              {t.nameZh}
            </span>
            <span className="text-[0.95rem]">{t.dates}</span>
            <span className="text-[0.95rem]">{t.place}</span>
          </p>
          <p className="mt-6 text-[1.1rem] leading-[1.85] text-stone-700">{t.oneLine}</p>

          {t.saying && (
            <div className="mt-10">
              <p className="mb-4 text-[0.68rem] uppercase tracking-[0.16em] text-stone-400">Known for saying</p>
              <Passage {...t.saying} big />
            </div>
          )}

          <div className="mt-12">
            <h2 className="mb-3 font-serif text-[1.3rem] text-stone-800">The story as the tradition tells it</h2>
            <p className="text-[1.02rem] leading-[1.85] text-stone-600">{t.story}</p>
            <h2 className="mt-8 mb-3 font-serif text-[1.3rem] text-stone-800">Why this person matters</h2>
            <p className="text-[1.02rem] leading-[1.85] text-stone-600">{t.why}</p>
          </div>
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <p className="mb-5 text-[0.68rem] uppercase tracking-[0.18em] text-stone-400">Dossier</p>
          <div className="rounded-lg border border-stone-200 bg-white/50 px-5">
            <Disclosure label="Place in the lineage" hint="who taught whom">
              <Field label="House or school">{t.house}</Field>
              <Field label="Teacher">
                {teacher ? (
                  <a className="text-[#9A3B1E] underline underline-offset-4" href={href("lineage", teacher.id)}>
                    {teacher.pinyin} {teacher.nameZh}
                  </a>
                ) : (
                  "Not recorded in this corpus."
                )}
              </Field>
              <Field label="Students in this corpus">
                <LinkRow
                  items={t.students
                    .map((s) => teacherById(s))
                    .filter(Boolean)
                    .map((s) => ({ label: s!.pinyin, room: "lineage", id: s!.id }))}
                />
              </Field>
            </Disclosure>
            <Disclosure label="Works connected to this person" hint="read">
              <LinkRow
                items={t.texts
                  .map((x) => textById(x))
                  .filter(Boolean)
                  .map((x) => ({ label: x!.titleEn, room: "read", id: x!.id }))}
              />
            </Disclosure>
            <Disclosure label="Cases they appear in" hint="koans">
              <LinkRow
                items={theirCases.map((c) => ({
                  label: `${c.collection} ${c.number}: ${c.titleEn}`,
                  room: "cases",
                  id: c.id,
                }))}
              />
            </Disclosure>
            <Disclosure label="How solid is the evidence?" hint="provenance">
              <p>
                Dates and relationships here follow the lamp histories, which were compiled between 952 and
                1252 — in most cases several centuries after the person lived. Treat the family tree as the
                tradition's own account of itself, checked against modern scholarship where it exists, and not
                as a birth register.
              </p>
            </Disclosure>
          </div>
        </aside>
      </div>
    </article>
  );
}

export default function Lineage({ id }: { id?: string }) {
  return id ? <Detail id={id} /> : <Index />;
}
