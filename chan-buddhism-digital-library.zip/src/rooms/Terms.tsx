import { useMemo, useState } from "react";
import { terms, termById } from "../data/terms";
import { textById } from "../data/texts";
import { href } from "../lib/router";
import { RoomTitle } from "../components/ui";

function Row({ id, forceOpen }: { id: string; forceOpen?: boolean }) {
  const t = termById(id)!;
  const [open, setOpen] = useState(!!forceOpen);
  return (
    <div id={t.id} className="border-b border-stone-200">
      <button onClick={() => setOpen((v) => !v)} className="group grid w-full gap-x-6 gap-y-1 py-5 text-left sm:grid-cols-[8rem_1fr]">
        <span className="flex items-baseline gap-3">
          <span lang="zh" className="text-[1.3rem] text-stone-700" style={{ fontFamily: "'Noto Serif SC', serif" }}>
            {t.zh}
          </span>
          <span className="text-[0.82rem] italic text-stone-400">{t.pinyin}</span>
        </span>
        <span>
          <span className="font-serif text-[1.1rem] text-stone-800 group-hover:text-[#9A3B1E]">{t.en}</span>
          <span className="mt-1 block max-w-[38rem] text-[0.97rem] leading-[1.7] text-stone-600">{t.plain}</span>
        </span>
      </button>
      {open && (
        <div className="grid gap-x-6 gap-y-4 pb-7 sm:grid-cols-[8rem_1fr]">
          <div />
          <div className="max-w-[38rem] space-y-4">
            <p className="text-[0.97rem] leading-[1.8] text-stone-600">{t.deeper}</p>
            <p className="text-[0.85rem] text-stone-500">
              <span className="text-stone-400">Literally: </span>
              {t.literal}
            </p>
            <div className="flex flex-wrap gap-x-6 gap-y-2 text-[0.85rem]">
              {t.related.length > 0 && (
                <p className="text-stone-500">
                  <span className="text-stone-400">Nearby words: </span>
                  {t.related.map((r, i) => (
                    <span key={r}>
                      {i > 0 && ", "}
                      <a className="text-[#9A3B1E] hover:underline" href={href("terms", r)}>
                        {termById(r)?.en ?? r}
                      </a>
                    </span>
                  ))}
                </p>
              )}
            </div>
            <p className="text-[0.85rem] text-stone-500">
              <span className="text-stone-400">Appears in: </span>
              {t.appearsIn.map((r, i) => (
                <span key={r}>
                  {i > 0 && ", "}
                  <a className="text-[#9A3B1E] hover:underline" href={href("read", r)}>
                    {textById(r)?.titleEn ?? r}
                  </a>
                </span>
              ))}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Terms({ id }: { id?: string }) {
  const [q, setQ] = useState("");
  const list = useMemo(
    () =>
      terms.filter((t) =>
        q.trim() ? (t.en + t.pinyin + t.zh + t.plain).toLowerCase().includes(q.toLowerCase()) : true,
      ),
    [q],
  );
  const focused = id ? termById(id) : undefined;

  return (
    <div className="mx-auto max-w-4xl px-5 py-16 sm:px-8">
      <RoomTitle
        eyebrow="Room five · Terms"
        title="The vocabulary, one sentence at a time"
        lede="Chan uses a small set of words over and over. Each one here gets a plain sentence first. Open a row if you want the longer answer, the literal sense of the characters, and where the word turns up."
      />

      {focused && (
        <div className="mb-10 rounded-lg border border-[#9A3B1E]/25 bg-white/60 p-6">
          <p className="text-[0.68rem] uppercase tracking-[0.16em] text-[#9A3B1E]">You followed a link to</p>
          <p className="mt-2 flex items-baseline gap-3">
            <span lang="zh" className="text-[1.6rem] text-stone-700" style={{ fontFamily: "'Noto Serif SC', serif" }}>
              {focused.zh}
            </span>
            <span className="font-serif text-[1.2rem] text-stone-800">{focused.en}</span>
            <span className="text-[0.85rem] italic text-stone-400">{focused.pinyin}</span>
          </p>
          <p className="mt-3 max-w-[38rem] text-[1rem] leading-[1.8] text-stone-600">{focused.plain}</p>
          <p className="mt-3 max-w-[38rem] text-[0.95rem] leading-[1.8] text-stone-500">{focused.deeper}</p>
        </div>
      )}

      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search terms — try 'mind', 'koan', 'empt'…"
        className="mb-8 w-full rounded-full border border-stone-300 bg-white/60 px-5 py-2.5 text-[0.95rem] text-stone-700 outline-none placeholder:text-stone-400 focus:border-[#9A3B1E]/50"
      />

      <div className="border-t border-stone-200">
        {list.map((t) => (
          <Row key={t.id} id={t.id} forceOpen={t.id === id} />
        ))}
      </div>
      {!list.length && <p className="py-10 text-stone-500">No term matches that.</p>}
    </div>
  );
}
