import { useState } from "react";
import { witnesses, variants, ledger } from "../data/terms";
import { textById } from "../data/texts";
import { href } from "../lib/router";
import { Disclosure, RoomTitle, StatusDot, usePrefs } from "../components/ui";

export default function Compare() {
  const [active, setActive] = useState(variants[0].id);
  const v = variants.find((x) => x.id === active)!;
  const prefs = usePrefs();

  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <RoomTitle
        eyebrow="Room two · Compare"
        title="When the copies disagree"
        lede="These texts survive in hand-copied manuscripts and carved woodblocks made centuries apart. Sometimes they say different things. This room shows the disagreements instead of quietly choosing a winner."
      />

      {/* the four witnesses */}
      <section className="mb-16">
        <h2 className="mb-2 font-serif text-[1.35rem] text-stone-800">The four witnesses</h2>
        <p className="mb-7 max-w-[40rem] text-[1rem] leading-[1.8] text-stone-600">
          A 'witness' is simply a surviving copy or edition that can testify to what a text said at a
          particular time and place. Four are used throughout this site.
        </p>
        <div className="grid gap-px overflow-hidden rounded-lg border border-stone-200 bg-stone-200 sm:grid-cols-2">
          {witnesses.map((w) => (
            <div key={w.id} className="bg-[#F8F5EF] p-7">
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="font-serif text-[1.15rem] text-stone-800">{w.nameEn}</h3>
                <span lang="zh" className="text-[0.9rem] text-stone-400" style={{ fontFamily: "'Noto Serif SC', serif" }}>
                  {w.nameZh}
                </span>
              </div>
              <p className="mt-1 text-[0.75rem] uppercase tracking-[0.12em] text-stone-400">
                {w.kind} · {w.dateLabel}
              </p>
              <p className="mt-3 text-[0.95rem] leading-[1.7] text-stone-600">{w.blurb}</p>
              <p className="mt-3 text-[0.85rem] leading-relaxed text-stone-500">
                <span className="text-stone-400">How far to trust it: </span>
                {w.reliability}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* collation table */}
      <section className="mb-16">
        <h2 className="mb-2 font-serif text-[1.35rem] text-stone-800">Three lines that do not agree</h2>
        <p className="mb-7 max-w-[40rem] text-[1rem] leading-[1.8] text-stone-600">
          Pick a line. The table shows what each witness actually carries — including where a witness carries
          nothing at all, which is itself evidence.
        </p>

        <div className="mb-8 flex flex-wrap gap-2">
          {variants.map((x) => (
            <button
              key={x.id}
              onClick={() => setActive(x.id)}
              className={`rounded-full px-4 py-1.5 text-[0.85rem] transition ${
                active === x.id
                  ? "bg-stone-800 text-[#F8F5EF]"
                  : "border border-stone-300 text-stone-600 hover:border-stone-500"
              }`}
            >
              {x.label.split("—")[0].trim()}
            </button>
          ))}
        </div>

        <div className="rounded-lg border border-stone-200 bg-white/50 p-7">
          <p className="text-[0.7rem] uppercase tracking-[0.16em] text-stone-400">{v.label}</p>
          <p className="mt-2 font-serif text-[1.3rem] leading-snug text-stone-800">{v.en}</p>
          <p className="mt-4 max-w-[42rem] text-[0.98rem] leading-[1.8] text-stone-600">{v.comment}</p>

          <div className="mt-8 divide-y divide-stone-200 border-t border-stone-200">
            {v.readings.map((r) => {
              const w = witnesses.find((x) => x.id === r.witnessId)!;
              return (
                <div key={r.witnessId} className="grid gap-x-8 gap-y-2 py-5 sm:grid-cols-[11rem_1fr]">
                  <div>
                    <p className="text-[0.92rem] font-medium text-stone-700">{w.nameEn}</p>
                    <p className="text-[0.75rem] text-stone-400">{w.dateLabel}</p>
                  </div>
                  <div>
                    <p
                      lang="zh"
                      className="text-[1.3rem] leading-[1.9] text-stone-800"
                      style={{ fontFamily: "'Noto Serif SC', 'Songti SC', serif" }}
                    >
                      {r.zh}
                    </p>
                    <p className="mt-2 flex flex-wrap items-center gap-3 text-[0.85rem] leading-relaxed text-stone-500">
                      <StatusDot status={r.status} withLabel />
                      <span className="max-w-[34rem]">{r.note}</span>
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <a
            href={href("read", v.textId)}
            className="mt-6 inline-block text-[0.9rem] text-[#9A3B1E] underline decoration-[#9A3B1E]/30 underline-offset-4"
          >
            Read {textById(v.textId)?.titleEn} →
          </a>
          {!prefs.zh && (
            <p className="mt-4 text-[0.8rem] text-stone-400">
              Tip: the 漢 button in the header keeps Chinese visible everywhere on the site.
            </p>
          )}
        </div>
      </section>

      {/* policy */}
      <section>
        <h2 className="mb-2 font-serif text-[1.35rem] text-stone-800">The rules this edition follows</h2>
        <p className="mb-7 max-w-[40rem] text-[1rem] leading-[1.8] text-stone-600">{ledger.policy}</p>
        <div className="rounded-lg border border-stone-200 bg-white/50 px-6">
          <Disclosure label="What counts as a verified quotation?" hint="177 of them">
            <p>
              A line is marked verified only when its characters have been checked against a named edition, the
              edition is recorded, and no competing reading has been found in the other witnesses — or, where
              one has, both are published side by side. Verification is about the Chinese. English translations
              here are editorial and are never described as verified.
            </p>
          </Disclosure>
          <Disclosure label="Why leave 630 slots flagged?" hint="visibly unfinished">
            <p>
              Because the alternative is quietly presenting an unchecked reading as settled. A flagged slot says:
              this wording circulates widely, we have not yet confirmed which edition it comes from, and you
              should not quote it as if we had.
            </p>
          </Disclosure>
          <Disclosure label="What is an 'unauthorised edit'?" hint="zero permitted">
            <p>
              Any change to a Chinese reading that is not documented: silently swapping a variant character,
              adding or moving punctuation that changes sense, converting between traditional and simplified
              forms, or harmonising two witnesses into one smooth text. None of these are performed here.
              Punctuation shown follows the cited edition.
            </p>
          </Disclosure>
          <Disclosure label="Can I check the work myself?" hint="yes">
            <p>
              Every passage names its edition where one has been confirmed. The Taishō canon and the Dunhuang
              manuscripts are both digitised and publicly searchable, and the site's data files are plain text
              in the repository, so a reading can be traced from screen to source without going through us.
            </p>
          </Disclosure>
        </div>
      </section>
    </div>
  );
}
