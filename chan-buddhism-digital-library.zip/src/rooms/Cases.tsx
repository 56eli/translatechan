import { useState } from "react";
import { cases, caseById } from "../data/cases";
import { teacherById } from "../data/teachers";
import { termById } from "../data/terms";
import { href } from "../lib/router";
import { Disclosure, LinkRow, Passage, RoomTitle } from "../components/ui";

function Index() {
  const collections = Array.from(new Set(cases.map((c) => c.collection)));
  const [filter, setFilter] = useState("All");
  const list = cases.filter((c) => filter === "All" || c.collection === filter);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <RoomTitle
        eyebrow="Room four · Cases"
        title="Koans, with the lights on"
        lede="A koan is a recorded exchange, usually a few lines long, used as a training device. The word means 'public case', as in a legal precedent. Nothing here is deliberately obscure: each case gets its setting, the point, and the usual way people get it wrong."
      />

      <div className="mb-10 flex flex-wrap gap-2">
        {["All", ...collections].map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`rounded-full px-3.5 py-1.5 text-[0.85rem] transition ${
              filter === c ? "bg-stone-800 text-[#F8F5EF]" : "border border-stone-300 text-stone-600 hover:border-stone-500"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="grid gap-px overflow-hidden rounded-lg border border-stone-200 bg-stone-200 sm:grid-cols-2">
        {list.map((c) => (
          <a key={c.id} href={href("cases", c.id)} className="group bg-[#F8F5EF] p-7 transition hover:bg-white">
            <p className="text-[0.7rem] uppercase tracking-[0.14em] text-stone-400">
              {c.collection} · case {c.number}
            </p>
            <h2 className="mt-2 font-serif text-[1.2rem] text-stone-800 group-hover:text-[#9A3B1E]">{c.titleEn}</h2>
            <p className="mt-3 max-w-[30rem] text-[0.95rem] leading-[1.7] text-stone-600">{c.en}</p>
            <p className="mt-4 text-[0.8rem] text-stone-400">read the case →</p>
          </a>
        ))}
      </div>
    </div>
  );
}

function Detail({ id }: { id: string }) {
  const c = caseById(id);
  if (!c) return <Index />;
  const i = cases.findIndex((x) => x.id === c.id);
  const prev = cases[(i - 1 + cases.length) % cases.length];
  const next = cases[(i + 1) % cases.length];

  return (
    <article className="mx-auto max-w-3xl px-5 py-14 sm:px-8">
      <a href={href("cases")} className="text-[0.85rem] text-stone-500 hover:text-[#9A3B1E]">
        ← all cases
      </a>

      <header className="mt-8 mb-10">
        <p className="mb-3 text-[0.7rem] uppercase tracking-[0.2em] text-[#9A3B1E]">
          {c.collection} · case {c.number}
        </p>
        <h1 className="font-serif text-[2.1rem] leading-tight text-stone-800">{c.titleEn}</h1>
        <p className="mt-3 flex flex-wrap items-baseline gap-x-4 text-stone-500">
          <span lang="zh" className="text-[1.35rem] text-stone-600" style={{ fontFamily: "'Noto Serif SC', serif" }}>
            {c.titleZh}
          </span>
          <span className="text-[0.92rem] italic">{c.titlePinyin}</span>
        </p>
      </header>

      <section className="mb-12">
        <Passage zh={c.zh} pinyin={c.pinyin} en={c.en} status={c.status} big />
      </section>

      <section className="mb-10 space-y-8">
        <div>
          <p className="mb-2 text-[0.68rem] uppercase tracking-[0.16em] text-stone-400">What is going on</p>
          <p className="text-[1.05rem] leading-[1.85] text-stone-700">{c.setting}</p>
        </div>
        <div>
          <p className="mb-2 text-[0.68rem] uppercase tracking-[0.16em] text-stone-400">What to notice</p>
          <p className="text-[1.05rem] leading-[1.85] text-stone-700">{c.pointer}</p>
        </div>
      </section>

      <div className="rounded-lg border border-stone-200 bg-white/50 px-5">
        <Disclosure label="The usual misreading" hint="careful">
          <p>{c.misread}</p>
        </Disclosure>
        <Disclosure label="People in this case" hint="lineage">
          <LinkRow
            items={c.teachers
              .map((t) => teacherById(t))
              .filter(Boolean)
              .map((t) => ({ label: t!.pinyin, room: "lineage", id: t!.id }))}
          />
        </Disclosure>
        <Disclosure label="Words used here" hint="terms">
          <LinkRow
            items={c.terms
              .map((t) => termById(t))
              .filter(Boolean)
              .map((t) => ({ label: t!.en, room: "terms", id: t!.id }))}
          />
        </Disclosure>
        <Disclosure label="Is a koan supposed to be solved?" hint="plain answer">
          <p>
            Not in the sense of finding the hidden meaning. A koan is worked, not solved: you hold it until the
            usual way of answering questions runs out of road. Traditionally a teacher checks the response in
            private, and the check is about how you meet it, not what you say.
          </p>
        </Disclosure>
      </div>

      <div className="mt-10 flex justify-between gap-4 text-[0.85rem]">
        <a href={href("cases", prev.id)} className="max-w-[45%] text-stone-500 hover:text-[#9A3B1E]">
          ← {prev.titleEn}
        </a>
        <a href={href("cases", next.id)} className="max-w-[45%] text-right text-stone-500 hover:text-[#9A3B1E]">
          {next.titleEn} →
        </a>
      </div>
    </article>
  );
}

export default function Cases({ id }: { id?: string }) {
  return id ? <Detail id={id} /> : <Index />;
}
