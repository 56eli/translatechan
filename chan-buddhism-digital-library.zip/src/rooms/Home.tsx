import { texts } from "../data/texts";
import { teachers } from "../data/teachers";
import { cases } from "../data/cases";
import { terms, witnesses, ledger } from "../data/terms";
import { href } from "../lib/router";
import { Passage } from "../components/ui";

const rooms = [
  {
    id: "read",
    zh: "讀",
    title: "Read",
    line: "Thirty-five source works, one at a time, with a plain-English dossier attached to each.",
    count: `${texts.length} works`,
  },
  {
    id: "compare",
    zh: "校",
    title: "Compare",
    line: "Where the manuscripts disagree, see both readings side by side and who carries which.",
    count: `${witnesses.length} witnesses`,
  },
  {
    id: "lineage",
    zh: "系",
    title: "Lineage",
    line: "Who taught whom, across eleven centuries — and what each of them is actually known for.",
    count: `${teachers.length} teachers`,
  },
  {
    id: "cases",
    zh: "案",
    title: "Cases",
    line: "Koans with their setting, the point, and the usual misreading — no mystification.",
    count: `${cases.length} cases`,
  },
  {
    id: "terms",
    zh: "語",
    title: "Terms",
    line: "The vocabulary, in one sentence each. Expand if you want the longer answer.",
    count: `${terms.length} terms`,
  },
];

export default function Home() {
  const opening = texts.find((t) => t.id === "xinxinming")!.passages[0];
  return (
    <div>
      {/* hero */}
      <section className="mx-auto max-w-6xl px-5 pt-20 pb-16 sm:px-8 sm:pt-28">
        <div className="max-w-[42rem]">
          <p className="mb-6 text-[0.7rem] uppercase tracking-[0.24em] text-[#9A3B1E]">
            Classical Chan Buddhism · 6th–17th century
          </p>
          <h1 className="font-serif text-[2.6rem] leading-[1.15] text-stone-800 sm:text-[3.2rem]">
            Old Chinese texts,
            <br />
            read at a human pace.
          </h1>
          <p className="mt-7 text-[1.1rem] leading-[1.85] text-stone-600">
            Chan is the Chinese tradition that became Zen in Japan. Its books are short, strange and often
            funny. They are also thirteen hundred years old, written in a language almost nobody reads, and
            usually presented as either a wall of scholarship or a fortune cookie.
          </p>
          <p className="mt-5 text-[1.1rem] leading-[1.85] text-stone-600">
            This site does neither. Every page starts in plain English, keeps the Chinese one click away, and
            tells you where the words came from.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <a
              href={href("read", "xinxinming")}
              className="rounded-full bg-stone-800 px-5 py-2.5 text-[0.92rem] text-[#F8F5EF] transition hover:bg-[#9A3B1E]"
            >
              Start with one poem
            </a>
            <a
              href={href("read")}
              className="rounded-full border border-stone-300 px-5 py-2.5 text-[0.92rem] text-stone-600 transition hover:border-stone-500"
            >
              Browse all {texts.length} works
            </a>
          </div>
        </div>
      </section>

      {/* first taste */}
      <section className="border-y border-stone-200/70 bg-[#F4F0E8]">
        <div className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
          <div className="max-w-[40rem]">
            <p className="mb-6 text-[0.68rem] uppercase tracking-[0.18em] text-stone-400">
              A line to begin with · Inscription on Trusting the Heart-Mind, 6th c.
            </p>
            <Passage
              en={opening.en}
              zh={opening.zh}
              pinyin={opening.pinyin}
              status={opening.status}
              note="Eight characters. The whole tradition argues with them for the next thousand years."
              big
            />
            <a
              href={href("read", "xinxinming")}
              className="mt-6 inline-block text-[0.9rem] text-[#9A3B1E] underline decoration-[#9A3B1E]/30 underline-offset-4"
            >
              Where did this come from? →
            </a>
          </div>
        </div>
      </section>

      {/* five rooms */}
      <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <h2 className="mb-2 font-serif text-[1.6rem] text-stone-800">Five rooms</h2>
        <p className="mb-10 max-w-[38rem] text-[1rem] leading-[1.8] text-stone-600">
          You never need more than one of them at a time. Pick whichever question you arrived with.
        </p>
        <div className="grid gap-px overflow-hidden rounded-lg border border-stone-200 bg-stone-200 sm:grid-cols-2 lg:grid-cols-3">
          {rooms.map((r) => (
            <a
              key={r.id}
              href={href(r.id)}
              className="group flex min-h-[11rem] flex-col bg-[#F8F5EF] p-7 transition hover:bg-white"
            >
              <div className="mb-4 flex items-baseline justify-between">
                <span className="font-serif text-[1.25rem] text-stone-800 group-hover:text-[#9A3B1E]">
                  {r.title}
                </span>
                <span
                  lang="zh"
                  className="text-[1.5rem] text-stone-300 group-hover:text-[#9A3B1E]/40"
                  style={{ fontFamily: "'Noto Serif SC', serif" }}
                >
                  {r.zh}
                </span>
              </div>
              <p className="text-[0.95rem] leading-[1.7] text-stone-600">{r.line}</p>
              <p className="mt-auto pt-5 text-[0.75rem] uppercase tracking-[0.14em] text-stone-400">{r.count}</p>
            </a>
          ))}
          <div className="flex min-h-[11rem] flex-col justify-center bg-[#F4F0E8] p-7">
            <p className="font-serif text-[1.05rem] text-stone-700">New to all of this?</p>
            <p className="mt-2 text-[0.92rem] leading-[1.7] text-stone-600">
              Read one koan, then one teacher, then stop. That is a complete visit.
            </p>
            <a href={href("cases", "wmg-7")} className="mt-4 text-[0.9rem] text-[#9A3B1E] underline underline-offset-4">
              Go wash your bowl →
            </a>
          </div>
        </div>
      </section>

      {/* integrity ledger */}
      <section className="border-t border-stone-200/70 bg-[#F4F0E8]">
        <div className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
          <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <p className="mb-3 text-[0.7rem] uppercase tracking-[0.22em] text-[#9A3B1E]">Source integrity</p>
              <h2 className="font-serif text-[1.7rem] leading-snug text-stone-800">
                The Chinese is the thing we are most careful about.
              </h2>
              <p className="mt-5 max-w-[38rem] text-[1rem] leading-[1.8] text-stone-600">{ledger.policy}</p>
              <a
                href={href("compare")}
                className="mt-6 inline-block text-[0.92rem] text-[#9A3B1E] underline decoration-[#9A3B1E]/30 underline-offset-4"
              >
                See how a disputed line is handled →
              </a>
            </div>
            <dl className="grid grid-cols-2 gap-px self-start overflow-hidden rounded-lg border border-stone-200 bg-stone-200">
              {[
                [ledger.slots.toLocaleString(), "text slots in the corpus", "Every discrete unit that can hold Chinese: a line, a title, a note."],
                [ledger.quotations.toString(), "verified quotations", "Checked character by character against a named edition."],
                [ledger.flagged.toString(), "flagged for source review", "Published as provisional, visibly marked, never quietly fixed."],
                ["0", "unauthorised edits", "No normalising of variants, no silent modernising of characters."],
              ].map(([n, label, note]) => (
                <div key={label} className="bg-[#F8F5EF] p-6">
                  <dt className="font-serif text-[1.9rem] text-stone-800">{n}</dt>
                  <dd className="mt-1 text-[0.85rem] font-medium text-stone-600">{label}</dd>
                  <dd className="mt-2 text-[0.8rem] leading-relaxed text-stone-500">{note}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      {/* how to read this site */}
      <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <div className="max-w-[40rem]">
          <h2 className="font-serif text-[1.6rem] text-stone-800">How this site is built to be read</h2>
          <ul className="mt-8 space-y-7">
            {[
              ["English first", "Every page opens in ordinary English. Chinese sits underneath, in full, whenever you ask for it — press 漢 in the header to keep it open everywhere."],
              ["Minimum by default", "Each entry shows one sentence. Origin, background, relations and provenance are all behind expanders, so nothing is a wall of text."],
              ["Nothing unexplained", "Where a technical word is unavoidable, it is linked to a one-sentence definition in the Terms room."],
              ["Provenance attached", "Each work says when it appeared, who wrote it down, how much later that was, and what is disputed."],
            ].map(([h, p]) => (
              <li key={h} className="border-l-2 border-[#9A3B1E]/25 pl-5">
                <p className="font-serif text-[1.08rem] text-stone-800">{h}</p>
                <p className="mt-1.5 text-[0.98rem] leading-[1.8] text-stone-600">{p}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
