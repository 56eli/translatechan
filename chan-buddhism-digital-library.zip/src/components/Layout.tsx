import type { ReactNode } from "react";
import { href } from "../lib/router";
import { usePrefs } from "./ui";

const rooms = [
  { id: "read", label: "Read", zh: "讀" },
  { id: "compare", label: "Compare", zh: "校" },
  { id: "lineage", label: "Lineage", zh: "系" },
  { id: "cases", label: "Cases", zh: "案" },
  { id: "terms", label: "Terms", zh: "語" },
];

export default function Layout({ room, children }: { room: string; children: ReactNode }) {
  const prefs = usePrefs();
  return (
    <div className="min-h-screen bg-[#F8F5EF] text-stone-800 antialiased">
      <header className="sticky top-0 z-30 border-b border-stone-200/70 bg-[#F8F5EF]/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-5 py-3 sm:px-8">
          <a href={href("home")} className="group flex items-baseline gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-[3px] bg-[#9A3B1E] text-[0.85rem] text-[#F8F5EF]">
              禪
            </span>
            <span className="font-serif text-[1.02rem] tracking-wide text-stone-700 group-hover:text-[#9A3B1E]">
              The Chan Room
            </span>
          </a>

          <nav className="order-3 -mx-1 flex w-full gap-1 overflow-x-auto sm:order-none sm:mx-0 sm:w-auto">
            {rooms.map((r) => {
              const active = room === r.id;
              return (
                <a
                  key={r.id}
                  href={href(r.id)}
                  className={`shrink-0 rounded-full px-3.5 py-1.5 text-[0.9rem] transition ${
                    active
                      ? "bg-stone-800 text-[#F8F5EF]"
                      : "text-stone-600 hover:bg-stone-800/5 hover:text-stone-900"
                  }`}
                >
                  {r.label}
                </a>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-1.5">
            <button
              onClick={prefs.toggleZh}
              title="Show Chinese everywhere"
              className={`rounded-full border px-2.5 py-1 text-[0.8rem] transition ${
                prefs.zh
                  ? "border-[#9A3B1E]/40 bg-[#9A3B1E]/10 text-[#9A3B1E]"
                  : "border-stone-300 text-stone-500 hover:border-stone-400"
              }`}
            >
              漢
            </button>
            <button
              onClick={prefs.togglePinyin}
              title="Show pinyin under Chinese"
              className={`rounded-full border px-2.5 py-1 text-[0.72rem] uppercase tracking-wide transition ${
                prefs.pinyin
                  ? "border-[#9A3B1E]/40 bg-[#9A3B1E]/10 text-[#9A3B1E]"
                  : "border-stone-300 text-stone-500 hover:border-stone-400"
              }`}
            >
              pīn
            </button>
          </div>
        </div>
      </header>

      <main>{children}</main>

      <footer className="mt-24 border-t border-stone-200/80 bg-[#F4F0E8]">
        <div className="mx-auto max-w-6xl px-5 py-12 sm:px-8">
          <div className="grid gap-10 sm:grid-cols-3">
            <div>
              <p className="font-serif text-[1.05rem] text-stone-700">The Chan Room</p>
              <p className="mt-2 max-w-sm text-[0.9rem] leading-relaxed text-stone-500">
                A reading edition of classical Chan sources. English first, Chinese always one click away,
                provenance always attached.
              </p>
            </div>
            <div>
              <p className="text-[0.68rem] uppercase tracking-[0.16em] text-stone-400">Rooms</p>
              <ul className="mt-3 space-y-1.5 text-[0.9rem] text-stone-600">
                {rooms.map((r) => (
                  <li key={r.id}>
                    <a className="hover:text-[#9A3B1E]" href={href(r.id)}>
                      {r.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[0.68rem] uppercase tracking-[0.16em] text-stone-400">Source integrity</p>
              <p className="mt-3 text-[0.9rem] leading-relaxed text-stone-500">
                Chinese text is never silently edited. Every line carries a status:
                <span className="mx-1 inline-flex items-center gap-1">
                  <span className="inline-block h-[7px] w-[7px] rounded-full bg-emerald-600" />verified
                </span>
                or
                <span className="mx-1 inline-flex items-center gap-1">
                  <span className="inline-block h-[7px] w-[7px] rounded-full bg-amber-500" />flagged
                </span>
                .
                <a className="ml-1 underline decoration-stone-300 underline-offset-4 hover:text-[#9A3B1E]" href={href("compare")}>
                  How we check
                </a>
              </p>
            </div>
          </div>
          <p className="mt-10 text-[0.78rem] text-stone-400">
            Public-domain source texts · translations and notes CC BY-SA · static site, no tracking.
          </p>
        </div>
      </footer>
    </div>
  );
}
