import { createContext, useContext, useState, type ReactNode } from "react";
import type { Status } from "../data/types";
import { href } from "../lib/router";

/* ---------- global display preferences ---------- */

interface Prefs {
  zh: boolean;
  pinyin: boolean;
  toggleZh: () => void;
  togglePinyin: () => void;
}
const PrefsCtx = createContext<Prefs>({
  zh: false,
  pinyin: false,
  toggleZh: () => {},
  togglePinyin: () => {},
});
export const usePrefs = () => useContext(PrefsCtx);

export function PrefsProvider({ children }: { children: ReactNode }) {
  const [zh, setZh] = useState(false);
  const [pinyin, setPinyin] = useState(false);
  return (
    <PrefsCtx.Provider
      value={{ zh, pinyin, toggleZh: () => setZh((v) => !v), togglePinyin: () => setPinyin((v) => !v) }}
    >
      {children}
    </PrefsCtx.Provider>
  );
}

/* ---------- small pieces ---------- */

export function Disclosure({
  label,
  children,
  hint,
  tone = "plain",
}: {
  label: string;
  children: ReactNode;
  hint?: string;
  tone?: "plain" | "quiet";
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`border-t border-stone-200/80 ${tone === "quiet" ? "" : ""}`}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="group flex w-full items-baseline gap-3 py-3.5 text-left"
      >
        <span
          className={`mt-0.5 inline-block w-3 shrink-0 text-[0.7rem] text-stone-400 transition-transform duration-200 ${
            open ? "rotate-90" : ""
          }`}
        >
          ▸
        </span>
        <span className="text-[0.95rem] font-medium text-stone-700 group-hover:text-[#9A3B1E]">{label}</span>
        {hint && <span className="ml-auto text-xs text-stone-400">{hint}</span>}
      </button>
      {open && <div className="pb-6 pl-6 text-[0.98rem] leading-[1.75] text-stone-600">{children}</div>}
    </div>
  );
}

export function StatusDot({ status, withLabel = false }: { status: Status; withLabel?: boolean }) {
  const map: Record<Status, [string, string, string]> = {
    verified: ["bg-emerald-600", "Verified", "Checked character by character against a named edition."],
    review: ["bg-amber-500", "Flagged for review", "Published as provisional; the reading still needs collation."],
    unsourced: ["bg-stone-300", "Not in this witness", "This edition carries no text for this line."],
  };
  const [color, label, tip] = map[status];
  return (
    <span className="inline-flex items-center gap-1.5 align-middle" title={tip}>
      <span className={`inline-block h-[7px] w-[7px] rounded-full ${color}`} />
      {withLabel && <span className="text-[0.7rem] uppercase tracking-[0.12em] text-stone-500">{label}</span>}
    </span>
  );
}

export function Chip({
  children,
  onClick,
  to,
}: {
  children: ReactNode;
  onClick?: () => void;
  to?: string;
}) {
  const cls =
    "inline-block rounded-full border border-stone-300/90 bg-white/60 px-3 py-1 text-[0.78rem] text-stone-600 transition hover:border-[#9A3B1E]/50 hover:text-[#9A3B1E]";
  if (to) return <a href={to} className={cls}>{children}</a>;
  return (
    <button onClick={onClick} className={cls}>
      {children}
    </button>
  );
}

export function RoomTitle({
  eyebrow,
  title,
  lede,
}: {
  eyebrow: string;
  title: string;
  lede: string;
}) {
  return (
    <header className="mb-12">
      <p className="mb-3 text-[0.7rem] uppercase tracking-[0.22em] text-[#9A3B1E]">{eyebrow}</p>
      <h1 className="font-serif text-[2.1rem] leading-tight text-stone-800">{title}</h1>
      <p className="mt-4 max-w-[38rem] text-[1.02rem] leading-[1.8] text-stone-600">{lede}</p>
    </header>
  );
}

/* A Chinese line with English first in the hierarchy. */
export function Passage({
  zh,
  pinyin,
  en,
  note,
  status,
  big = false,
}: {
  zh: string;
  pinyin: string;
  en: string;
  note?: string;
  status: Status;
  big?: boolean;
}) {
  const prefs = usePrefs();
  const [localZh, setLocalZh] = useState(false);
  const showZh = big || prefs.zh || localZh;
  return (
    <figure className="border-l-2 border-[#9A3B1E]/25 py-1 pl-5">
      <p className={`font-serif text-stone-800 ${big ? "text-[1.22rem] leading-[1.85]" : "text-[1.08rem] leading-[1.8]"}`}>
        {en}
      </p>
      {showZh && (
        <p
          lang="zh"
          className={`mt-3 text-stone-700 ${
            big ? "text-[1.7rem] leading-[1.9] tracking-[0.04em]" : "text-[1.15rem] leading-[1.9]"
          }`}
          style={{ fontFamily: "'Noto Serif SC', 'Songti SC', 'SimSun', serif" }}
        >
          {zh}
        </p>
      )}
      {showZh && prefs.pinyin && (
        <p className="mt-1.5 text-[0.86rem] italic leading-relaxed text-stone-500">{pinyin}</p>
      )}
      <figcaption className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1">
        {!big && (
          <button
            onClick={() => setLocalZh((v) => !v)}
            className="text-[0.75rem] text-stone-400 underline-offset-4 hover:text-[#9A3B1E] hover:underline"
          >
            {showZh ? "hide Chinese" : "show Chinese 漢"}
          </button>
        )}
        <StatusDot status={status} withLabel />
      </figcaption>
      {note && <p className="mt-2 max-w-[34rem] text-[0.85rem] leading-relaxed text-stone-500">{note}</p>}
    </figure>
  );
}

export function LinkRow({ items }: { items: { label: string; room: string; id: string }[] }) {
  if (!items.length) return <p className="text-sm text-stone-400">Nothing linked yet.</p>;
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((i) => (
        <Chip key={i.room + i.id} to={href(i.room, i.id)}>
          {i.label}
        </Chip>
      ))}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-5">
      <p className="mb-1 text-[0.68rem] uppercase tracking-[0.16em] text-stone-400">{label}</p>
      <div className="text-[0.98rem] leading-[1.75] text-stone-600">{children}</div>
    </div>
  );
}
