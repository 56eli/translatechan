# The Chan Room

A reading edition of classical Chan (Chinese Zen) sources: 35 works, 50 teachers, 24 koan cases,
40+ technical terms and 4 textual witnesses. English first, Chinese always one click away,
provenance attached to everything.

## Design principles

- **English first** — every page opens in plain English; Chinese is present but subordinate,
  except in the reading column where the Chinese is the largest type on the page.
- **Minimum by default** — one sentence per entry; origin, background, relations and provenance
  live behind expanders.
- **Source integrity** — Chinese readings are never normalised, re-punctuated or harmonised.
  Each line carries a status: verified (checked against a named edition) or flagged for review.
  Disagreements between witnesses are published side by side in the Compare room.

## Rooms

`Read` · `Compare` · `Lineage` · `Cases` · `Terms` — routed with the URL hash, so the whole site
is a single static file.

## Hosting on GitHub Pages

```bash
npm install
npm run build        # produces dist/index.html — a single self-contained file
```

Then either:

1. Push the contents of `dist/` to a `gh-pages` branch, or
2. Copy `dist/index.html` to `docs/index.html` on `main` and set
   **Settings → Pages → Source: main / docs**.

Because routing is hash-based (`#/read/xinxinming`) no 404 rewrite rules or base-path
configuration are needed, and deep links survive a hard refresh.

## Editing the corpus

All content lives in `src/data/`:

- `texts.ts` — works, passages, provenance, slot counts
- `teachers.ts` — lineage, story, significance
- `cases.ts` — koans with setting, pointer and common misreading
- `terms.ts` — vocabulary, the four witnesses, variant collations, the integrity ledger

Chinese strings in these files are treated as read-only source data: change them only with a
citation to the edition being followed.
